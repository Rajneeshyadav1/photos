//package com.cts.static_test;
//
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.Iterator;
//import java.util.List;
//
//import org.springframework.stereotype.Component;
//
//@Component
//public class CustomerDao {
//	
//	
//	private static int customercount=100;
//	
//	private static List<Customer> customers=new ArrayList<>();
//	
//	static {
//		customers.add(new Customer(1,"Ram",new Date(),"123abc","abc123"));
//		customers.add(new Customer(2,"Hanuman",new Date(),"123def","def123"));
//		customers.add(new Customer(3,"Ravan",new Date(),"123ghi","ghi123"));
//	}
//	
//	public List<Customer> findAll()
//	{
//		return customers;
//		
//	}
//	public Customer save(Customer customer)
//	{
////		if (customer.getId() == null) {
////			customer.setId(++customercount);
////		}
//		customers.add(customer);
//		return customer;
//		
//	}
//	
//	public Customer findOne(int id) {
//		for (Customer customer : customers) {
//			if (customer.getId() == id) {
//				return customer;
//			}
//		}
//		return null;
//	}
//
//	public Customer deleteById(int id) {
//		Iterator<Customer> iterator = customers.iterator();
//		while (iterator.hasNext()) {
//			Customer customer = iterator.next();
//			if (customer.getId() == id) {
//				iterator.remove();
//				return customer;
//			}
//		}
//		return null;
//	}
//	
//
//}
