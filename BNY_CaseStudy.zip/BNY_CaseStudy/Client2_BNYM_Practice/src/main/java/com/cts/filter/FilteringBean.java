package com.cts.filter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value={"password"})
public class FilteringBean {
	
	private String name;
	
	private String password;
	
	private String pan;
	
	

	public FilteringBean(String name, String password, String pan) {
		super();
		this.name = name;
		this.password = password;
		this.pan = pan;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}
	
	

}
