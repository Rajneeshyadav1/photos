package com.cts.filter;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FilterController {
	
	//only name and pan
	@GetMapping("/filtering")
	public FilteringBean retriveFilteringBean()
	{
		FilteringBean filteringBean=new FilteringBean("Ram", "123abc", "321abc");
		return filteringBean;
		
	}

}
