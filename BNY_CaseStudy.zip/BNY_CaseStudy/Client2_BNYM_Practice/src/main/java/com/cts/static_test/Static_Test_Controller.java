//package com.cts.static_test;

//public class Static_Test_Controller {

//	@GetMapping("/customer")
//	public List<Customer> allCustomer(){
//		return service.findAll();
//	}
//	
//	//get studentById
//	@GetMapping("/customer/{id}")
//	public Customer getById(@PathVariable int id)
//	{
//		Customer customer=service.findOne(id);
//		if(customer==null)
//			throw new CustomerNotFoundException("id::"+id);
//		return customer;
//	}
//	
//	//post service...
//	
//	@PostMapping("/create")
//	public ResponseEntity<Object> createCustomer(@Valid @RequestBody Customer customer) {
//		Customer savedCustomer = service.save(customer);
//		// CREATED
//		// /user/{id}     savedUser.getId()
//		
//		URI location = ServletUriComponentsBuilder
//			.fromCurrentRequest()
//			.path("/{id}")
//			.buildAndExpand(savedCustomer.getId()).toUri();
//		
//		return ResponseEntity.created(location).build();
//		
//	}
//	//delete service....
//	@DeleteMapping("/delete/{id}")
//	public void deleteCustomer(@PathVariable int id) {
//		Customer customer = service.deleteById(id);
//		
//		if(customer==null)
//			throw new CustomerNotFoundException("id-"+ id);		
//	}

//}
