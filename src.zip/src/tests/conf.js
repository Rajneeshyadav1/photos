exports.config = {
    framework: 'jasmine',
    seleniumAddress: 'http://localhost:4444/wd/hub',
    specs: ['E:/mcAngular/BankManagementSystemFE/e2e/src/app.e2e-spec.ts']
  }