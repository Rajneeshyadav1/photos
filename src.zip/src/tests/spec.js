const { element, by } = require("protractor");

describe('Protractor Demo App', function() {
    it('should have a title', function() {
      browser.get('http://localhost:4200/home/login');
  
    //   expect(browser.getTitle()).toEqual('BankManagementSystemFE');
      element(by.id('login')).sendKeys('GWVPS9753L');
    //   element(by.id('password')).sendKeys('mat');
    //   element(by.id('signIn')).click();
    expect(element(by.id('login')).getAttribute('value')).toEqual('GWVPS9752L');
    //   browser.get('http://localhost:4200/homem/accountdetails');

    //   expect(element(by.binding('name1')).getText()).toEqual('MATHESH KOLIMI');
    // browser.get('http://juliemr.github.io/protractor-demo/');
    // element(by.model('first')).sendKeys(3);
    // element(by.model('second')).sendKeys(2);

    // element(by.id('gobutton')).click();

    // expect(element(by.binding('latest')).getText()).
        // toEqual('5');
    });
  });