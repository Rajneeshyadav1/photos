import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import{ReactiveFormsModule} from '@angular/forms';
import { SidebarComponent } from './sidebar/sidebar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { PersonalInfoComponent } from './personal-info/personal-info.component'; 
import {HttpClientModule} from '@angular/common/http';
import { ModifiedSidebarComponent } from './modified-sidebar/modified-sidebar.component'
// import {MatButtonModule} from '@angular/material/button';
// import { MatSliderModule } from '@angular/material/slider';
import {ToastrModule} from 'ngx-toastr'
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    HomeComponent,
    SidebarComponent,
    AccountDetailsComponent,
    PersonalInfoComponent,
    ModifiedSidebarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,NgbModule,FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,HttpClientModule,
    ToastrModule.forRoot()
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
