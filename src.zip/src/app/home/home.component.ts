import { Component, OnInit, ElementRef } from '@angular/core';
import { FormControl, FormGroup, NgModel, NgForm } from '@angular/forms';
import {Validators} from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
  homeForm: FormGroup;
  // name=new FormControl('');
  // email=new FormControl('');
  constructor() { }

  ngOnInit() {
    this.homeForm=new FormGroup({
      'name': new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      'email':new FormControl('',[Validators.required,Validators.email])
    });
  }
  onsubmit(){
    console.log(this.homeForm);
  }
}
