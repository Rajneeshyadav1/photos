import { Injectable } from '@angular/core';
import { LoginData } from '../model/LoginData';

@Injectable({
  providedIn: 'root'
})
export class PersonalService {
 

  customer:LoginData;
  constructor() { }

  save(customer1:LoginData){
    this.customer=customer1;
    console.log(this.customer);
    console.log(customer1);
  }
  getData(): LoginData {
    return this.customer;
  }
}
