import { TestBed } from '@angular/core/testing';

import { MutualfundService } from './mutualfund.service';

describe('MutualfundService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MutualfundService = TestBed.get(MutualfundService);
    expect(service).toBeTruthy();
  });
});
