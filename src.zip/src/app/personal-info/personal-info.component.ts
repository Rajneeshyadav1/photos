import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { PersonalService } from '../services/personal.service';
import { LoginData } from '../model/LoginData';
import { Router } from '@angular/router';
@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {

  name1:string;
  customer:LoginData;
  constructor(private http:HttpClient,private personal:PersonalService,private router:Router) { }

  ngOnInit() {
    this.name1=window.localStorage.getItem('name');
    if(this.name1!=null){
      this.fetchdata();
    }else{
      this.router.navigate(['home/login']);
    }
  }

  private fetchdata(){
      this.customer= this.personal.getData();
  }

  // private fetchdata(){
  //   this.http.get('https://bankmanagement-9e85b.firebaseio.com/posts.json')
  //   .pipe(
  //     map(responses=>{
  //       const postArrays=[];
  //       for(const post in responses){
  //         if(responses.hasOwnProperty(post)){
  //             postArrays.push({...responses[post], id:post});
  //         }
  //       }
  //       return postArrays;
  //     })
  //   )
  //   .subscribe(res=>{
  //     this.customer2=res;
  //   });

  // }

}
