import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from '../services/notification/notification.service';

@Component({
  selector: 'app-modified-sidebar',
  templateUrl: './modified-sidebar.component.html',
  styleUrls: ['./modified-sidebar.component.css']
})
export class ModifiedSidebarComponent implements OnInit {

  name:string;
  constructor(private routers:Router,private notification:NotificationService) { }

  ngOnInit() {
    this.name=window.localStorage.getItem('name');
  }
  logout(){
    window.localStorage.clear();
    console.clear();
    this.routers.navigate(['']);
    this.notification.showSuccess("your data is deleted in the browser and it is safe with  us","logout success");
  }

}
