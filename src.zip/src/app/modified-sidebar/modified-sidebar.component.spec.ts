import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifiedSidebarComponent } from './modified-sidebar.component';

describe('ModifiedSidebarComponent', () => {
  let component: ModifiedSidebarComponent;
  let fixture: ComponentFixture<ModifiedSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifiedSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifiedSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
