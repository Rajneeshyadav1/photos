import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { PersonalInfoComponent } from './personal-info/personal-info.component';
import { ModifiedSidebarComponent } from './modified-sidebar/modified-sidebar.component';

const routes: Routes = [
  {path:'',redirectTo:'home/login',pathMatch:'full'},
  // {path:'register',component:RegistrationComponent},
  // {path:'login',component:LoginComponent},
  // {path:'accountdetails',component:AccountDetailsComponent},
  // {path:'home',component: HomeComponent},
  {path:'home',component: SidebarComponent,children:[
    {path:'login',component:LoginComponent},
    {path:'register',component:RegistrationComponent}]},

  {path:'homem',component: ModifiedSidebarComponent,children:[
      {path:'login',redirectTo:'../home/login'},
      {path:'personal',component:PersonalInfoComponent},
      {path:'accountdetails',component:AccountDetailsComponent}]}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
