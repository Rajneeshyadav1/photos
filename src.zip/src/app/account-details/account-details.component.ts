import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  addAccount:boolean=false;
  name1:string;
  AccountNumber:number;
  accountForm:FormGroup;
  constructor(private router:Router) { }

  ngOnInit() {
    this.name1=window.localStorage.getItem('name');
    if(this.name1!=null){
    this.accountForm=new FormGroup({
      'AccountType':new FormControl('',Validators.required),
      'InitialDepositAmount':new FormControl('',[Validators.required,Validators.min(5000)])
    });
  }
  else{
    this.router.navigate(['home/login']);
  }
  }
  AddAccount(){
    this.addAccount=true;
  }

  createAccount(){
    this.AccountNumber=(Math.random()*1000000000000000);
    this.addAccount=false;
  }

}
