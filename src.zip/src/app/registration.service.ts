import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './model/customer';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private http:HttpClient) { }

  onpost(customer:Customer){
    this.http.post('https://bankmanagementproject.firebaseio.com/post.json',customer).subscribe(response=>{
      console.log(response);
    });
  }
}
