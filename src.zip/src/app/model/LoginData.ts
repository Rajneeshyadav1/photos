export class LoginData{
      custId:string;
	  firstName:string;
	  lastName:string;
	  userPan:string;
	  email:string;
	  phoneNo:string;
	  dob:Date;
}