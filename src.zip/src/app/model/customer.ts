
import { Accounts } from './Accounts';

export class Customer{
    Name:string;
    Pan:string;
    Username:string;
    password:string;
    Confirmpassword:string;
    GuardianType:string;
    GuardianName:string;
    Address:string;
    Citizenship:string;
    State:string;
    Country:string;
    Email:string;
    Gender:string;
    Maretial:string;
    Mobile:number;
    Dob:Date;
    registration:Date;
    AccountType:string;
    BranchName:string;
    Citizen:string;
    InitialDepositAmount:string;
    Identification:string;
    DocumentNo:string;
    ReferenceName:string;
    ReferenceNo:string;
    ReferenceAddress:string;
}