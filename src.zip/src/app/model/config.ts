import { LoginData } from './LoginData';

export interface Config{
    additionalMessage:string;
    data:LoginData;
    success:boolean;
}