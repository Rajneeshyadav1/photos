import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule ,Router} from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { RegistrationService } from '../registration.service';
import {DatePipe} from '@angular/common';
import { Customer } from '../model/customer';
import {HttpClient} from '@angular/common/http';
import { DummyCustomer } from '../model/DummyCustomer';
import { Config } from '../model/config';
import { NotificationService } from '../services/notification/notification.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registrationForm:FormGroup;
  firstName:string;
  userPan:string;
  lastName:string;
  email:string;
  phoneNo:string;
  dob:Date;
  custId:string;
  password:string;
  // customer:Customer;
  constructor(private router: Router,private registration:RegistrationService, private http:HttpClient,private Fb:FormBuilder,private natification:NotificationService) {}

  ngOnInit() {
    // this.registrationForm=this.Fb.group({
    //   'Name':[null,[Validators.required,Validators.minLength(6)]],
    //   'Pan':[null,[Validators.required]],
    //   'LastName':[null,[Validators.required,Validators.minLength(6)]],
    //   'Email':[null,[Validators.required]],
    //   'Mobile':[null,[Validators.required,Validators.minLength(6)]],
    //   'Password':[null,[Validators.required]],
    //   'Dob':[null,[Validators.required,Validators.minLength(6)]],
    //   'custId':[null,[Validators.required]]
    // });
    this.registrationForm=new FormGroup({
      
      'firstName':new FormControl('',[Validators.required]),
      'userPan':new FormControl('',[Validators.required,Validators.pattern("[A-Z]{5}[0-9]{4}[A-Z]{1}"),Validators.maxLength(10),Validators.minLength(10)]),
      'lastName':new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(16)]),
      'password':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(24)]),
      'dob':new FormControl('',[Validators.required,Validators.min(18)]),
      'email':new FormControl('',[Validators.required]),
      'phoneNo':new FormControl('',[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
      'custId':new FormControl('',[Validators.required])
      // 'id':new FormControl('')


      // 'Username':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'password':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'Confirmpassword':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'GuardianType':new FormControl(''),
      // 'GuardianName':new FormControl(''),
      // 'Address':new FormControl(''),
      // 'Citizenship':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'State':new FormControl(''),
      // 'Country':new FormControl(''),
      // 'Email':new FormControl('',[Validators.required,Validators.email]),
      // 'Gender':new FormControl(''),
      // 'Maretial':new FormControl(''),
      // 'Mobile':new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(13)]),
      // 'Dob':new FormControl('',[Validators.required]),
      // 'registration':new FormControl(''),
      // 'AccountType':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'BranchName':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(20)]),
      // 'Citizen':new FormControl(''),
      // 'InitialDepositAmount':new FormControl('',[Validators.required,Validators.min(5000)]),
      // 'Identification':new FormControl(''),
      // 'DocumentNo':new FormControl(''),
      // 'ReferenceName':new FormControl(''),
      // 'ReferenceNo':new FormControl(''),
      // 'ReferenceAddress':new FormControl('')
    });

    // this.customer.name=this.registrationForm.get('Name');
    
  }

   submitted(){
    //  let id:string=Math.random().toPrecision(6);
    //  this.custId=JSON.stringify(id*1000000);
    //  console.log(this.custId);
    let firstNamec=(<HTMLInputElement>document.getElementById('firstName')).value;
    let userPanc=(<HTMLInputElement>document.getElementById('userPan')).value;
    let lastNamec=(<HTMLInputElement>document.getElementById('lastName')).value;
    let emailc=(<HTMLInputElement>document.getElementById('email')).value;
    let phoneNoc=(<HTMLInputElement>document.getElementById('phoneNo')).value;
    let dobc=(<HTMLInputElement>document.getElementById('dob')).value;
    // const dateOfBirth=new DatePipe('').transform(dobc,'mm/dd/yyyy');
    var stringDate1=dobc;
    var splitDate1 = stringDate1.split('-');
    var year1  = splitDate1[0];
    var month1 = splitDate1[1];
    var day1 = splitDate1[2];
    dobc = month1+"/"+day1+"/"+year1;
    console.log(dobc);
    // console.log(dateOfBirth);

    let custIdc=(<HTMLInputElement>document.getElementById('custId')).value;
    let passwordc=(<HTMLInputElement>document.getElementById('password')).value;

     let customer2=new DummyCustomer(firstNamec,userPanc,lastNamec,emailc,phoneNoc,dobc,custIdc,passwordc);
    // customer1
    // this.customer.name="mathesh";
    // this.customer.mobileNo=8886065214;
    // customer1=this.customer;
    //  this.registration.onpost(this.customer);
    //   window.alert("successful");
    //   this.router.navigate(['sidebar/login']);
    this.http.post('http://localhost:9090/register',customer2).subscribe((res:Config)=>{
      if(res.success){
          console.log(res);
          this.natification.showSuccess("You have successfully registered","registration success");
      }
      else{
        this.natification.showError("registration failed","failed");
      }
    });
    console.log(this.registrationForm);
    console.log(customer2);
      this.router.navigate(['home/login']);
    }

    // onSubmit(){
    //   console.log(this.registrationForm);
    // }

}
