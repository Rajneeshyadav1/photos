import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Config } from '../model/config';
import { Router } from '@angular/router';
import { PersonalService } from '../services/personal.service';
import { NotificationService } from '../services/notification/notification.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;
  config:Config;
  jaffa:Config;
  // username:string;
  constructor(private httpClient:HttpClient,private router:Router,private personal:PersonalService,private notification:NotificationService) { }

  ngOnInit() {
    this.loginForm=new FormGroup({
      'username':new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(25)]),
      'password':new FormControl('',[Validators.required,Validators.minLength(7),Validators.maxLength(16)])
    })
  }

  signin(){
    let userPanc=(<HTMLInputElement>document.getElementById("login")).value;
    let passwordc=(<HTMLInputElement>document.getElementById("password")).value;
    // localStorage.setItem('password',"Mathesh");
    // window.localStorage.setItem('username',this.loginForm.get('username').value);
    let url=`http://localhost:9090/login/${userPanc}/${passwordc}`;
    this.httpClient.get(url).subscribe((res:Config)=>{
      console.log(res.data);
      this.personal.save(res.data);
      window.localStorage.setItem('name',res.data.firstName+" "+res.data.lastName);
      // window.sessionStorage.setItem('name',res.data.firstName+" "+res.data.lastName);
      if(res.additionalMessage==="login successful"){
      this.showSuccessMessagee();
      this.router.navigate(['homem/accountdetails']);
      }
      else{
        this.showErrorMessage();
        this.router.navigate(['/home/login']);
      }
    });
  }
  showSuccessMessagee(){
    this.notification.showSuccess("you have successfully logged in!","login success");
  }
  showErrorMessage(){
    this.notification.showError("please try again with correct password","login unsuccess");
  }

}
