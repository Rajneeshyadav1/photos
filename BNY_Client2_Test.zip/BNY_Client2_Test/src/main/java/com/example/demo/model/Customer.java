package com.example.demo.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customer_table_pune2")
public class Customer {

    @Id
    @GeneratedValue
    private int id;
    private String name;
    private String lastName;
    private String pan;
    private String password;
    private String dob;


}