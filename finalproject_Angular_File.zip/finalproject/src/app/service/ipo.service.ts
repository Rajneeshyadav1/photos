import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { IpoModel } from 'src/entity/IpoModel';
import { Observable } from 'rxjs';
type EntityResponseType = HttpResponse<IpoModel[]>;
@Injectable({
  providedIn: 'root'
})
export class IpoService {

  constructor(private http:HttpClient) { }

  getAllIpo():Observable<EntityResponseType>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<IpoModel[]>("http://localhost:9003/ipos", {observe: 'response'});
}

saveIpo(ipoModel:IpoModel){
   return this.http.post<IpoModel>("http://localhost:9003/ipo", ipoModel, {observe: 'response'});
}
}