import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { exchange } from 'src/entity/exchange';
type EntityResponseType = HttpResponse<exchange[]>
@Injectable({
  providedIn: 'root'
})
export class ExchangeService {
  constructor(private http: HttpClient) { }
  getAll(): Observable<EntityResponseType> {

    return this.http.get<exchange[]>("http://localhost:9002/stocks", { observe: 'response' });
  }


  save(ob: exchange) {
    return this.http.post<exchange>("http://localhost:9002/stock", ob, { observe: 'response' });

  }
  update(exchang: exchange) {
    return this.http.put<exchange>("http://localhost:8333/exchange", exchang, { observe: 'response' });
  }
  delete(id) {
    return this.http.delete<exchange>("http://localhost:8333/exchange/" + id);
  }
}
