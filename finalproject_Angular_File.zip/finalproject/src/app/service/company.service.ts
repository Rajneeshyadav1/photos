import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CompanyModel } from 'src/entity/CompanyModel';

type EntityResponseType1 = HttpResponse<CompanyModel[]>;


@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private http:HttpClient) { }
  getAllCompany():Observable<EntityResponseType1>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<CompanyModel[]>("http://localhost:8095/companies", {observe: 'response'});
  }
  
  saveCompany(companyModel:CompanyModel){
   return this.http.post<CompanyModel>("http://localhost:8095/company", companyModel, {observe: 'response'});
  }
  updateCompany(companyModel:CompanyModel){
    return this.http.put<CompanyModel>("http://localhost:8095/company", companyModel, {observe: 'response'});
   }
   deleteCompany(id){
    return this.http.delete<CompanyModel>("http://localhost:8095/company/"+id);
   }
   getById(id){
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<CompanyModel[]>("http://localhost:8095/company/"+id);
  }
}
