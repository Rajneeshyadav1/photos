import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload';
import { ExcelService } from 'src/app/excel.service';
import { UserModel } from 'src/entity/UserModel';
import { Router } from '@angular/router';
@Component({
  selector: 'app-importdata',
  templateUrl: './importdata.component.html',
  styleUrls: ['./importdata.component.css']
})
export class ImportdataComponent implements OnInit {

  users:UserModel[];
  currentFileUpload:File;
  selectedFiles:FileList;

  constructor(private service:ExcelService,private router:Router) { }
selectFile(event){
  this.selectedFiles=event.target.files;
}

  ngOnInit() :void {
    this.service.getAllUser().subscribe(data => {
         this.users = data.body;
         console.log(data.body)
        
    });
  }
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.service.pushFileToStorage(this.currentFileUpload).subscribe(event => {
     if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
        alert("File Successfully Uploaded")
      }
    });
    this.selectedFiles = undefined;
  }

}

