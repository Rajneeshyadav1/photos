import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { exchange } from 'src/entity/exchange';
import { ExchangeService } from '../service/exchange.service';

@Component({
  selector: 'app-manageexchange',
  templateUrl: './manageexchange.component.html',
  styleUrls: ['./manageexchange.component.css']
})
export class ManageexchangeComponent implements OnInit {
  exchange: exchange[];
  e: any;
  constructor(private service: ExchangeService, private route: Router) { }

  ngOnInit(): void {
    this.service.getAll().subscribe(data => {
      this.exchange = data.body;
      console.log(this.exchange);


    });

  }
  refresh(): void {
    window.location.reload();
  }
  update(id: number) {
    this.route.navigate(['updat', id]);
  }
  delete(id): void {
    console.log(id);
    this.service.delete(id).subscribe(data =>
      this.e = data
    );
    
   this.refresh();
  }

  
}
