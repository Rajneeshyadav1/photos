import { Component, OnInit } from '@angular/core';
import { CompanyModel } from 'src/entity/CompanyModel';
import { CompanyService } from '../service/company.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-createcompany',
  templateUrl: './createcompany.component.html',
  styleUrls: ['./createcompany.component.css']
})
export class CreatecompanyComponent implements OnInit {
  user:CompanyModel[];
  myForm3:FormGroup

  constructor(private service:CompanyService, private router:Router){}
  ngOnInit(): void {
    this.service.getAllCompany().subscribe(data => {
         this.user = data.body;
         console.log(data.body)
    });
    {
    this.myForm3=new FormGroup({
      company_name:new FormControl(''),
      turnover:new FormControl(''),
      ceo:new FormControl(''),
      board:new FormControl(''),
      listed:new FormControl(''),
      sector:new FormControl(''),
      writeup:new FormControl(''),
      stckcode:new FormControl(''),
    });
  }
    
  
}
  onSubmit(myForm3: FormGroup)
{
  let user:CompanyModel={
    id:myForm3.value.id,
    company_name:myForm3.value.company_name,
   turnover:myForm3.value.turnover,
    ceo:myForm3.value.ceo,
    board:myForm3.value.board,
    listed:myForm3.value.listed,
    sector:myForm3.value.sector,
    writeup:myForm3.value.writeup,
    stckcode:myForm3.value.stckcode,
  }
  this.service.saveCompany(user).subscribe(data =>{
    console.log(data.body);
      });
      this.router.navigate(['/']);
      
} 

}
