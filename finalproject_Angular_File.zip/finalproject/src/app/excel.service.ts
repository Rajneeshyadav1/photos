import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from 'src/entity/UserModel';

type EntityResponseType = HttpResponse<UserModel[]>;
@Injectable({
  providedIn: 'root'
})
export class ExcelService {
  

  constructor(private http:HttpClient) { }

  getAllUser():Observable<EntityResponseType>{
        //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
        return this.http.get<UserModel[]>("http://localhost:9001/stockData", {observe: 'response'});
  }


  
  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const req = new HttpRequest('POST', 'http://localhost:9001/import', formdata, {
      reportProgress: true,
      responseType: 'text'
    }
    );
    return this.http.request(req);
  }
  
  
  

}
